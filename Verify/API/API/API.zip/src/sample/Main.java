package sample;

import java.io.*;
import java.net.*;
import org.json.*;


public class Main {
public static void main(String[] args) throws Exception {
	// Create a JSON object to hold the data
	String name = "maz";
    String temp1="tett";
    String temp2="tett2";
    // Create a URL object for the API endpoint
    String url = "https://lis.thelabquest.com/api/fingerpost?Name=" + name + "&Temp1="+temp1+"&Temp2="+temp2;
    URL obj = new URL(url);
    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
    if (con != null)
     {System.out.println("conntected");}

    // Open a connection to the API endpoint
    con.setRequestMethod("POST");
    con.setDoOutput(true);
    DataOutputStream wr = new DataOutputStream(con.getOutputStream());
    wr.flush();
    wr.close();

    int responseCode = con.getResponseCode();
    System.out.println("\nSending 'POST' request to URL : " + url);
    System.out.println("Response Code : " + responseCode);

    BufferedReader in = new BufferedReader(
            new InputStreamReader(con.getInputStream()));
    String inputLine;
    StringBuffer response = new StringBuffer();

    while ((inputLine = in.readLine()) != null) {
        response.append(inputLine);
    }
    in.close();

    //print result
    System.out.println(response.toString());
}
}



