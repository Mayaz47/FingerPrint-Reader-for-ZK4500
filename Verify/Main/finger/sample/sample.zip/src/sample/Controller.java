package sample;

import com.zkteco.biometric.FingerprintSensorEx;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.awt.Desktop;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.io.*;
import java.net.*;
import org.json.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.core.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.sql.Blob;
import java.sql.SQLException;
import javax.sql.rowset.serial.SerialBlob;
import javafx.scene.control.Button;
import javazoom.jl.player.Player;

public class Controller implements Initializable {
    @FXML
    ImageView imageView;
    @FXML
    ImageView image1;
    @FXML
    ImageView image2;
    @FXML
    ImageView image3;
    @FXML
    TextField nameField;
    
    @FXML
    Label nameLabel;
    
    @FXML
    Button exit;
    
    @FXML
    Label sc;



    //the width of fingerprint image
    private int fpWidth = 0;
    //the height of fingerprint image
    private int fpHeight = 0;
    private byte[] imgbuf;
    private byte[] template = new byte[2048];
    private int[] templateLen = new int[1];
    private long mhDB = 0;
    private long device = 0;
    private byte[] paramValue = new byte[4];
    private int[] size = new int[1];

    private boolean Running = true;

    IntegerProperty scannerProperty = new SimpleIntegerProperty();

    private int count = 1;
    

    private String fingerPrintTemplateForDB1 = "";
    private String fingerPrintTemplateForDB2 = "";
    private String fingerPrintTemplateForDB3 = "";

    Map<Integer, PersonInfo> map =  new HashMap<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scannerProperty.addListener((observable, oldValue, newValue) -> {
            if (newValue.equals(0)) {
                OnCaptureOK(imgbuf);
            }
        });
        initFingerPrint();
        try {
			fetchDataFromDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        exit.setStyle("-fx-background-color: linear-gradient(#2e2928, #2e2928),radial-gradient(center 50% -40%, radius 200%, #ed7b2f 45%, #c93b14 50%);"+"-fx-background-radius: 6, 5;"+"-fx-background-insets: 0, 1;"+"-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.4) , 5, 0.0 , 0 , 1 );"+"-fx-text-fill: #395306;"+"-fx-text-fill: white;"+" -fx-font: bold italic 11pt 'Arial';");
        onStart();

    }

    private void initFingerPrint(){
        System.out.println("Init: " + FingerprintSensorEx.Init());

        device = FingerprintSensorEx.OpenDevice(0);
        System.out.println("device: " + device);

        size[0] = 4;
        System.out.println("Parameter: " + FingerprintSensorEx.GetParameters(device, 1, paramValue, size));
        fpWidth = byteArrayToInt(paramValue);
        size[0] = 4;
        FingerprintSensorEx.GetParameters(device, 2, paramValue, size);
        fpHeight = byteArrayToInt(paramValue);

        imgbuf = new byte[fpWidth * fpHeight];

        mhDB = FingerprintSensorEx.DBInit();

        int nFmt = 0;
        FingerprintSensorEx.DBSetParameter(mhDB, 5010, nFmt);
        Running = true;
    }

    private void fetchDataFromDB() throws Exception{
        
    	
        String url = "https://gccfinger.thelabquest.com/fingerdata";

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");
        con.setRequestProperty("tsltoken", Main.Token());

        int responseCode = con.getResponseCode();
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        int fid = 1;
        // parse the JSON data from the API
        String jsonData = response.toString();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonData);
        
        for (JsonNode item : root) {
        	int id = item.get("ID").intValue();
            String name = item.get("Name").textValue();
            String temp1 = item.get("temp1").textValue();
            String temp2 = item.get("temp2").textValue();
            String temp3 = item.get("temp3").textValue();
            
            System.out.println("ID"+" "+id+" "+"Name: " + name+" "+"Temp1 :"+" "+temp1+" "+"Temp2; "+" "+temp2+"Temp3; "+" "+temp3);
            PersonInfo person = new PersonInfo(id, name);
            System.out.println(temp3);
            
            byte[] finger1 = new byte[2048];
            byte[] finger2 = new byte[2048];
            byte[] finger3 = new byte[2048];
            
            System.out.println(temp1);
            FingerprintSensorEx.Base64ToBlob(temp1, finger1, 2048);
            System.out.println("here is blob:"+FingerprintSensorEx.Base64ToBlob(temp2, finger2, 2048));
            FingerprintSensorEx.Base64ToBlob(temp3, finger3, 2048);
            for(int i = 0; i < finger1.length; i++) {
                System.out.println(finger1[i] & 0xff);
            }
            System.out.println(mhDB); 
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger1));
            map.put(fid, person);
            ++fid;
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger2));
            map.put(fid, person);
            ++fid;
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger3));
            map.put(fid, person);
            ++fid;
        }
    }

    public void onVerify(){
        int[] fid = new int[1];
        int[] score = new int[1];
        int v=FingerprintSensorEx.DBIdentify(mhDB, template,fid, score);
        System.out.println("Identify: " + v);
        if(v==-17) {
        	 try {
	                FileInputStream fileInputStream = new FileInputStream("F:\\Fingerprint reader\\Main\\finger\\sample\\failed.mp3");
	                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
	                Player player = new Player(bufferedInputStream);
	                player.play();
	            } catch (Exception e) {
	                System.out.println("Error playing sound: " + e.getMessage());
	            }
        	Platform.runLater(() -> {
    		nameLabel.setText("Not Identified");
    		nameLabel.setStyle("-fx-text-fill : red;");
    	});}
        else {
        if (fid[0] != 0 && score[0] > 70){
            PersonInfo personInfo = map.get(fid[0]);

            if (personInfo != null){
            	String url = "https://github.com/"+personInfo.name;

                if (Desktop.isDesktopSupported()) {
                  try {
                    Desktop.getDesktop().browse(new URI(url));
                  } catch (Exception e) {
                    e.printStackTrace();
                  }
                }
                try {
	                FileInputStream fileInputStream = new FileInputStream("F:\\Fingerprint reader\\Main\\finger\\sample\\complete.mp3");
	                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
	                Player player = new Player(bufferedInputStream);
	                player.play();
	            } catch (Exception e) {
	                System.out.println("Error playing sound: " + e.getMessage());
	            }

            	Platform.runLater(() -> {
            		sc.setText("Score: "+score[0]+"%");
            		nameLabel.setText("  Your name is " + personInfo.name);
            		nameLabel.setStyle("-fx-text-fill : green;");
            		
            	});
            	
                
            }
            
        }
    }}
 
    

    public void onOpen() {
        initFingerPrint();
        try {
			fetchDataFromDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public void onStop() {
        Running = false;
        System.exit(0);
    }
    public void onStart() {
    	imageView.setImage(new Image(new File("F:\\Fingerprint reader\\Main\\finger\\sample\\finger2.gif").toURI().toString(), true));
        Task<Void> task = new Task<Void>() {
            
        	@Override

            protected Void call() throws Exception {
            	try {
	                FileInputStream fileInputStream = new FileInputStream("F:\\Fingerprint reader\\Main\\finger\\sample\\press.mp3");
	                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
	                Player player = new Player(bufferedInputStream);
	                player.play();
	            } catch (Exception e) {
	                System.out.println("Error playing sound: " + e.getMessage());
	            }
                while (Running) {
                    templateLen[0] = 2048;
                    int value = FingerprintSensorEx.AcquireFingerprint(device, imgbuf, template, templateLen);
                    System.out.println("value: " + value);
                    
                     scannerProperty.setValue(value);
                     
                     if(value==0) {
                    	 
                    	 onVerify();}
                     


                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                Platform.runLater(() -> FreeSensor());
                return null;
            }
        };
        new Thread(task).start();

    }

    public int byteArrayToInt(byte[] bytes) {
        int number = bytes[0] & 0xFF;
        number |= ((bytes[1] << 8) & 0xFF00);
        number |= ((bytes[2] << 16) & 0xFF0000);
        number |= ((bytes[3] << 24) & 0xFF000000);
        return number;
    }

    private void OnCaptureOK(byte[] imgBuf) {
        File file = null;
        try {
            writeBitmap(imgBuf, fpWidth, fpHeight);
            file = new File("fingerprint.bmp");
            BufferedImage bufferedImage = ImageIO.read(file);

            Image image = SwingFXUtils.toFXImage(bufferedImage, null);
            imageView.setImage(image);
            
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (file != null){
                file.delete();
            }
        }
    }


    private static void writeBitmap(byte[] imageBuf, int nWidth, int nHeight) throws IOException {
        java.io.FileOutputStream fos = new java.io.FileOutputStream("fingerprint.bmp");
        java.io.DataOutputStream dos = new java.io.DataOutputStream(fos);

        int w = (((nWidth + 3) / 4) * 4);
        int bfType = 0x424d;
        int bfSize = 54 + 1024 + w * nHeight;
        int bfReserved1 = 0;
        int bfReserved2 = 0;
        int bfOffBits = 54 + 1024;

        dos.writeShort(bfType);
        dos.write(changeByte(bfSize), 0, 4);
        dos.write(changeByte(bfReserved1), 0, 2);
        dos.write(changeByte(bfReserved2), 0, 2);
        dos.write(changeByte(bfOffBits), 0, 4);

        int biSize = 40;
        int biPlanes = 1;
        int biBitcount = 8;
        int biCompression = 0;
        int biSizeImage = w * nHeight;
        int biXPelsPerMeter = 0;
        int biYPelsPerMeter = 0;
        int biClrUsed = 0;
        int biClrImportant = 0;

        dos.write(changeByte(biSize), 0, 4);
        dos.write(changeByte(nWidth), 0, 4);
        dos.write(changeByte(nHeight), 0, 4);
        dos.write(changeByte(biPlanes), 0, 2);
        dos.write(changeByte(biBitcount), 0, 2);
        dos.write(changeByte(biCompression), 0, 4);
        dos.write(changeByte(biSizeImage), 0, 4);
        dos.write(changeByte(biXPelsPerMeter), 0, 4);
        dos.write(changeByte(biYPelsPerMeter), 0, 4);
        dos.write(changeByte(biClrUsed), 0, 4);
        dos.write(changeByte(biClrImportant), 0, 4);

        for (int i = 0; i < 256; i++) {
            dos.writeByte(i);
            dos.writeByte(i);
            dos.writeByte(i);
            dos.writeByte(0);
        }

        byte[] filter = null;
        if (w > nWidth) {
            filter = new byte[w - nWidth];
        }

        for (int i = 0; i < nHeight; i++) {
            dos.write(imageBuf, (nHeight - 1 - i) * nWidth, nWidth);
            if (w > nWidth)
                dos.write(filter, 0, w - nWidth);
        }
        dos.flush();
        dos.close();
        fos.close();
    }

    private static byte[] intToByteArray(final int number) {
        byte[] abyte = new byte[4];

        abyte[0] = (byte) (0xff & number);

        abyte[1] = (byte) ((0xff00 & number) >> 8);
        abyte[2] = (byte) ((0xff0000 & number) >> 16);
        abyte[3] = (byte) ((0xff000000 & number) >> 24);
        return abyte;
    }

    private void FreeSensor() {
        try {        //wait for thread stopping
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (0 != mhDB) {
            FingerprintSensorEx.DBFree(mhDB);
            mhDB = 0;
        }
        if (0 != device) {
            FingerprintSensorEx.CloseDevice(device);
            device = 0;
        }
        FingerprintSensorEx.Terminate();
    }

    private static byte[] changeByte(int data) {
        return intToByteArray(data);
    }

    private static class PersonInfo{
        int id;
        String name;

        PersonInfo(int id, String name){
            this.id = id;
            this.name = name;
        }
    }

}
