package sample;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.fasterxml.jackson.databind.*;
import java.sql.SQLException;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import javazoom.jl.player.Player;

public class Main extends Application {
	 private Stage popup;
	 public static String token;
	 
	  @Override
	  public void start(Stage primaryStage) throws Exception {
	    // Show the login popup
	    if (!showLoginPopup(primaryStage)) {
	      return;
	    }

	  
	  }

	  private boolean showLoginPopup(Stage primaryStage) {
	    GridPane grid = new GridPane();
	    grid.setAlignment(Pos.CENTER);
	    grid.setHgap(10);
	    grid.setVgap(10);
	    grid.setPadding(new Insets(25, 25, 25, 25));

	    Label usernameLabel = new Label("Username:");
	    grid.add(usernameLabel, 0, 0);

	    TextField usernameField = new TextField();
	    grid.add(usernameField, 1, 0);

	    Label passwordLabel = new Label("Password:");
	    grid.add(passwordLabel, 0, 1);

	    PasswordField passwordField = new PasswordField();
	    grid.add(passwordField, 1, 1);
	    
	    Label Login = new Label(" ");
	    grid.add(Login, 1, 2);

	    Button loginButton = new Button("Login");
	    grid.add(loginButton, 1, 3);
	    
	   

	    loginButton.setOnAction(event -> {
	      String username = usernameField.getText();
	      String password = passwordField.getText();
	      
	      String url = "https://gccfinger.thelabquest.com/login?user_id="+username+"&user_password="+password;
	      URL obj = null;
		try {
			obj = new URL(url);
		} catch (MalformedURLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	        HttpURLConnection con=null;
			try {
				con = (HttpURLConnection) obj.openConnection();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        if (con != null)
	         {System.out.println("conntected");}

	        // Open a connection to the API endpoint
	        try {
				con.setRequestMethod("POST");
			} catch (ProtocolException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        con.setDoOutput(true);
	        DataOutputStream wr=null;
			try {
				wr = new DataOutputStream(con.getOutputStream());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        try {
				wr.flush();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        try {
				wr.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	        int responseCode = 0;
			try {
				responseCode = con.getResponseCode();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        System.out.println("\nSending 'POST' request to URL : " + url);
	        System.out.println("Response Code : " + responseCode);

	        BufferedReader in = null;
			try {
				in = new BufferedReader(
				        new InputStreamReader(con.getInputStream()));
			} catch (IOException e1) {
				Login.setText("Login failed, please try again");
				
				e1.printStackTrace();
			}
	        String inputLine;
	        StringBuffer response = new StringBuffer();

	        try {
				while ((inputLine = in.readLine()) != null) {
				    response.append(inputLine);
				}
			} catch (IOException e1) {
				Login.setText("Login failed, please try again");
				
				e1.printStackTrace();
			}
	        try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	        //print result
	        
	        System.out.println(response.toString());

	        int index = response.indexOf("tsltoken");

	     // Extract the substring from the "tsltoken" key to the end of the input string
	     token = response.substring(index + 11);

	     // Extract the substring from the start of the input string to the "tsltoken" key
	     String result = response.substring(0, index);
         token=token.replace("}", "");
         token = token.replace("\"", "");
	     System.out.println("Token: " + token);
	     System.out.println("Result: " + result);
	     
	     
	    
	        
	        

	      // Perform authentication
	      if (responseCode==200) {
	    	  try {
	                FileInputStream fileInputStream = new FileInputStream("F:\\finger\\sample\\welcome.mp3");
	                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
	                Player player = new Player(bufferedInputStream);
	                player.play();
	            } catch (Exception e) {
	                System.out.println("Error playing sound: " + e.getMessage());
	            }
	        System.out.println("Login successful!");
	       
	        Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource("sample.fxml"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    primaryStage.setTitle("Finger Print");
		    primaryStage.setScene(new Scene(root));
		    primaryStage.show();
	        popup.close();
	        
	       
	      } else {
	        System.out.println("Login failed.");
	        Login.setText("Login failed, please try again");
	      }
	    });

	    Scene scene = new Scene(grid, 300, 200);

	    popup = new Stage();
	    popup.initModality(Modality.APPLICATION_MODAL);
	    popup.initOwner(primaryStage);
	    popup.setScene(scene);
	    popup.showAndWait();

	    // Return true if the popup is closed (i.e., if the login is successful)
	    return popup.isShowing();
	  }
	  public static String Token() {
	    	return token;
	    	 
	     }
	  public static void main(String[] args) {
	    launch(args);
	  }
	}

