package sample;

import com.zkteco.biometric.FingerprintSensorEx;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.concurrent.Task;
import javafx.css.PseudoClass;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import javafx.scene.control.Button;
import javafx.scene.media.MediaException;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.io.*;
import java.net.*;
import org.json.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.core.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.sql.Blob;
import java.sql.SQLException;
import javax.sql.rowset.serial.SerialBlob;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import javazoom.jl.player.Player;
import com.bumptech.glide.Glide;

public class Controller implements Initializable {
    @FXML
    ImageView imageView;
    @FXML
    ImageView image1;
    @FXML
    ImageView image2;
    @FXML
    ImageView image3;
    @FXML
    TextField nameField;
    
    @FXML
    Label nameLabel;
    
    @FXML
    Button exit;
    
    @FXML
    Button accept;



    //the width of fingerprint image
    private int fpWidth = 0;
    //the height of fingerprint image
    private int fpHeight = 0;
    private byte[] imgbuf;
    private byte[] template = new byte[2048];
    private int[] templateLen = new int[1];
    private long mhDB = 0;
    private long device = 0;
    private byte[] paramValue = new byte[4];
    private int[] size = new int[1];

    private boolean Running = true;

    IntegerProperty scannerProperty = new SimpleIntegerProperty();

    private int count = 1;
    
    private String fingerPrintTemplateForDB1 = "";
    private String fingerPrintTemplateForDB2 = "";
    private String fingerPrintTemplateForDB3 = "";
    
    String pressedStyle = "-fx-background-color: linear-gradient(#171716, #171716),radial-gradient(center 50% -40%, radius 200%, #677537 45%, #677537 50%);"+"-fx-background-radius: 6, 5;"+"-fx-background-insets: 0, 1;"+"-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.4) , 5, 0.0 , 0 , 1 );"+"-fx-text-fill: #395306;"+"-fx-text-fill: black;"+" -fx-font: bold italic 11pt 'Arial';";
    String defaultStyle = "-fx-background-color: linear-gradient(#171716, #171716),radial-gradient(center 50% -40%, radius 200%, #cfe014 45%, #acb733 50%);"+"-fx-background-radius: 6, 5;"+"-fx-background-insets: 0, 1;"+"-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.4) , 5, 0.0 , 0 , 1 );"+"-fx-text-fill: #395306;"+"-fx-text-fill: black;"+" -fx-font: bold italic 11pt 'Arial';";
    PseudoClass pressed = PseudoClass.getPseudoClass("pressed");

    Map<Integer, PersonInfo> map =  new HashMap<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scannerProperty.addListener((observable, oldValue, newValue) -> {
            if (newValue.equals(0)) {
                OnCaptureOK(imgbuf);
            }
        });
        initFingerPrint();
        try {
			fetchDataFromDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        exit.setStyle("-fx-background-color: linear-gradient(#2e2928, #2e2928),radial-gradient(center 50% -40%, radius 200%, #ed7b2f 45%, #c93b14 50%);"+"-fx-background-radius: 6, 5;"+"-fx-background-insets: 0, 1;"+"-fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.4) , 5, 0.0 , 0 , 1 );"+"-fx-text-fill: #395306;"+"-fx-text-fill: black;"+" -fx-font: bold italic 11pt 'Arial';");
        accept.setStyle(defaultStyle);
        
        onStart();

    }

    private void initFingerPrint(){
        System.out.println("Init: " + FingerprintSensorEx.Init());

        device = FingerprintSensorEx.OpenDevice(0);
        System.out.println("device: " + device);

        size[0] = 4;
        System.out.println("Parameter: " + FingerprintSensorEx.GetParameters(device, 1, paramValue, size));
        fpWidth = byteArrayToInt(paramValue);
        size[0] = 4;
        FingerprintSensorEx.GetParameters(device, 2, paramValue, size);
        fpHeight = byteArrayToInt(paramValue);

        imgbuf = new byte[fpWidth * fpHeight];

        mhDB = FingerprintSensorEx.DBInit();

        int nFmt = 0;
        FingerprintSensorEx.DBSetParameter(mhDB, 5010, nFmt);
        Running = true;
    }

    private void fetchDataFromDB() throws Exception{
        
    	
        String url = "https://lis.thelabquest.com/api/fingerdata";

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");
        con.setRequestProperty("tsltoken", Main.Token());

        int responseCode = con.getResponseCode();
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        int fid = 1;
        // parse the JSON data from the API
        String jsonData = response.toString();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(jsonData);
        
        for (JsonNode item : root) {
        	int id = item.get("ID").intValue();
            String name = item.get("Name").textValue();
            String temp1 = item.get("temp1").textValue();
            String temp2 = item.get("temp2").textValue();
            String temp3 = item.get("temp3").textValue();
            
            System.out.println("ID"+" "+id+" "+"Name: " + name+" "+"Temp1 :"+" "+temp1+" "+"Temp2; "+" "+temp2+"Temp3; "+" "+temp3);
            PersonInfo person = new PersonInfo(id, name);
            System.out.println(temp3);
            
            byte[] finger1 = new byte[2048];
            byte[] finger2 = new byte[2048];
            byte[] finger3 = new byte[2048];
            
            System.out.println(temp1);
            FingerprintSensorEx.Base64ToBlob(temp1, finger1, 2048);
            System.out.println("here is blob:"+FingerprintSensorEx.Base64ToBlob(temp2, finger2, 2048));
            FingerprintSensorEx.Base64ToBlob(temp3, finger3, 2048);
            for(int i = 0; i < finger1.length; i++) {
                System.out.println(finger1[i] & 0xff);
            }
            System.out.println(mhDB); 
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger1));
            map.put(fid, person);
            ++fid;
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger2));
            map.put(fid, person);
            ++fid;
            System.out.println("DBAdd: "+FingerprintSensorEx.DBAdd(mhDB, fid, finger3));
            map.put(fid, person);
            ++fid;
        }
    }

    
    public void onAccept(){
        if (count == 1){
            image1.setImage(imageView.getImage());
            fingerPrintTemplateForDB1 = FingerprintSensorEx.BlobToBase64(template, templateLen[0]);
            ++count;
            try {
                FileInputStream fileInputStream = new FileInputStream("F:\\finger\\sample\\2more.mp3");
                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                Player player = new Player(bufferedInputStream);
                player.play();
            } catch (Exception e) {
                System.out.println("Error playing sound: " + e.getMessage());
            }
            Platform.runLater(() -> {
	    		nameLabel.setText("Press your finger 2 times");
	    	});
        }else
        if (count == 2){
            image2.setImage(imageView.getImage());
            fingerPrintTemplateForDB2 = FingerprintSensorEx.BlobToBase64(template, templateLen[0]);
            ++count;
            try {
                FileInputStream fileInputStream = new FileInputStream("F:\\finger\\sample\\last.mp3");
                BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                Player player = new Player(bufferedInputStream);
                player.play();
            } catch (Exception e) {
                System.out.println("Error playing sound: " + e.getMessage());
            }
            Platform.runLater(() -> {
	    		nameLabel.setText("Press your finger 1 time");
	    	});
        }
       else
            if (count == 3){
                image3.setImage(imageView.getImage());
                fingerPrintTemplateForDB3 = FingerprintSensorEx.BlobToBase64(template, templateLen[0]);
                count = 1;
                try {
                    FileInputStream fileInputStream = new FileInputStream("F:\\finger\\sample\\submit.mp3");
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                    Player player = new Player(bufferedInputStream);
                    player.play();
                } catch (Exception e) {
                    System.out.println("Error playing sound: " + e.getMessage());
                }
                Platform.runLater(() -> {
    	    		nameLabel.setText("Done. Please Submit");
    	    		nameLabel.setStyle("-fx-text-fill : green;");
    	    	});
            }
    }

    public void onSubmit()throws Exception{
    	accept.pseudoClassStateChanged(pressed, true);
        PauseTransition pause = new PauseTransition(Duration.seconds(0.1));
        pause.setOnFinished(e -> accept.pseudoClassStateChanged(pressed, false));
        pause.play();
        String name = nameField.getText();
        String temp1=fingerPrintTemplateForDB1;
        String temp2=fingerPrintTemplateForDB2;
        String temp3=fingerPrintTemplateForDB3;
        // Create a URL object for the API endpoint
        String url = "https://gccfinger.thelabquest.com/fingerpost?Name=" + name + "&Temp1="+temp1+"&Temp2="+temp2+"&Temp3="+temp3;
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        if (con != null)
         {System.out.println("conntected");}

        // Open a connection to the API endpoint
        con.setRequestMethod("POST");
        con.setRequestProperty("tsltoken", Main.Token());
        con.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.flush();
        wr.close();

        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'POST' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //print result
        System.out.println(response.toString());
        image1.setImage(null);
        image2.setImage(null);
        image3.setImage(null);
        imageView.setImage(null);
        onClose();
		 initFingerPrint();
		 Platform.runLater(() -> {
	    		nameLabel.setText("Press your finger 3 times");
	    		nameLabel.setStyle("-fx-text-fill : blue;");
	    	});
		 onStart();
    }

   

    private   void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());

                Throwable t = ex.getCause();

                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

    public void onOpen() {
        initFingerPrint();
        try {
			fetchDataFromDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    public void onClose() {
        Running = false;}
    public void onStop() {
        Running = false;
        System.exit(0);
    }
    
    public void onStart() {
    	try {
    	    Image image = new Image(new File("F:\\Fingerprint reader\\Main\\finger\\sample\\finger1.gif").toURI().toString(), true);
    	    imageView.setImage(new Image(new File("F:\\Fingerprint reader\\Main\\finger\\sample\\finger2.gif").toURI().toString(), true));
    	    image1.setImage(image);
    	    image2.setImage(image);
    	    image3.setImage(image);
    	
    	    // Add the ImageView to your layout or scene
    	} catch (MediaException e) {
    	    System.out.println("Failed to load the GIF file: " + e.getMessage());
    	}
    	 
        Task<Void> task = new Task<Void>() {
        	
        	
            @Override
            protected Void call() throws Exception {
            	try {
                    FileInputStream fileInputStream = new FileInputStream("F:\\finger\\sample\\start.mp3");
                    BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
                    Player player = new Player(bufferedInputStream);
                    player.play();
                } catch (Exception e) {
                    System.out.println("Error playing sound: " + e.getMessage());
                }
                while (Running) {
                    templateLen[0] = 2048;
                    int value = FingerprintSensorEx.AcquireFingerprint(device, imgbuf, template, templateLen);
                    System.out.println("value: " + value);
                    
                     scannerProperty.setValue(value);
                     
                     if(value==0) {
                    	 
                    	 onAccept();}
                     


                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                Platform.runLater(() -> FreeSensor());
                return null;
            }
        };
        new Thread(task).start();

    }

    public int byteArrayToInt(byte[] bytes) {
        int number = bytes[0] & 0xFF;
        number |= ((bytes[1] << 8) & 0xFF00);
        number |= ((bytes[2] << 16) & 0xFF0000);
        number |= ((bytes[3] << 24) & 0xFF000000);
        return number;
    }

    private void OnCaptureOK(byte[] imgBuf) {
        File file = null;
        try {
            writeBitmap(imgBuf, fpWidth, fpHeight);
            file = new File("fingerprint.bmp");
            BufferedImage bufferedImage = ImageIO.read(file);

            Image image = SwingFXUtils.toFXImage(bufferedImage, null);
            imageView.setImage(image);
            
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (file != null){
                file.delete();
            }
        }
    }


    private static void writeBitmap(byte[] imageBuf, int nWidth, int nHeight) throws IOException {
        java.io.FileOutputStream fos = new java.io.FileOutputStream("fingerprint.bmp");
        java.io.DataOutputStream dos = new java.io.DataOutputStream(fos);

        int w = (((nWidth + 3) / 4) * 4);
        int bfType = 0x424d;
        int bfSize = 54 + 1024 + w * nHeight;
        int bfReserved1 = 0;
        int bfReserved2 = 0;
        int bfOffBits = 54 + 1024;

        dos.writeShort(bfType);
        dos.write(changeByte(bfSize), 0, 4);
        dos.write(changeByte(bfReserved1), 0, 2);
        dos.write(changeByte(bfReserved2), 0, 2);
        dos.write(changeByte(bfOffBits), 0, 4);

        int biSize = 40;
        int biPlanes = 1;
        int biBitcount = 8;
        int biCompression = 0;
        int biSizeImage = w * nHeight;
        int biXPelsPerMeter = 0;
        int biYPelsPerMeter = 0;
        int biClrUsed = 0;
        int biClrImportant = 0;

        dos.write(changeByte(biSize), 0, 4);
        dos.write(changeByte(nWidth), 0, 4);
        dos.write(changeByte(nHeight), 0, 4);
        dos.write(changeByte(biPlanes), 0, 2);
        dos.write(changeByte(biBitcount), 0, 2);
        dos.write(changeByte(biCompression), 0, 4);
        dos.write(changeByte(biSizeImage), 0, 4);
        dos.write(changeByte(biXPelsPerMeter), 0, 4);
        dos.write(changeByte(biYPelsPerMeter), 0, 4);
        dos.write(changeByte(biClrUsed), 0, 4);
        dos.write(changeByte(biClrImportant), 0, 4);

        for (int i = 0; i < 256; i++) {
            dos.writeByte(i);
            dos.writeByte(i);
            dos.writeByte(i);
            dos.writeByte(0);
        }

        byte[] filter = null;
        if (w > nWidth) {
            filter = new byte[w - nWidth];
        }

        for (int i = 0; i < nHeight; i++) {
            dos.write(imageBuf, (nHeight - 1 - i) * nWidth, nWidth);
            if (w > nWidth)
                dos.write(filter, 0, w - nWidth);
        }
        dos.flush();
        dos.close();
        fos.close();
    }

    private static byte[] intToByteArray(final int number) {
        byte[] abyte = new byte[4];

        abyte[0] = (byte) (0xff & number);

        abyte[1] = (byte) ((0xff00 & number) >> 8);
        abyte[2] = (byte) ((0xff0000 & number) >> 16);
        abyte[3] = (byte) ((0xff000000 & number) >> 24);
        return abyte;
    }

    private void FreeSensor() {
        try {        //wait for thread stopping
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (0 != mhDB) {
            FingerprintSensorEx.DBFree(mhDB);
            mhDB = 0;
        }
        if (0 != device) {
            FingerprintSensorEx.CloseDevice(device);
            device = 0;
        }
        FingerprintSensorEx.Terminate();
    }

    private static byte[] changeByte(int data) {
        return intToByteArray(data);
    }

    private static class PersonInfo{
        int id;
        String name;

        PersonInfo(int id, String name){
            this.id = id;
            this.name = name;
        }
    }

}
